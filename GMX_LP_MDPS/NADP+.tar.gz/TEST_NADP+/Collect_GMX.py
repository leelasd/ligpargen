import os
from collections import OrderedDict
import sys

fil = open(sys.argv[1]+'/LOG_GMX').readlines()
fil = [line.strip()[:35] for line in fil[6:]]
DATA = {}
for  l in fil: 
	names= l[:25]
	value= l[25:]
	DATA[names.strip()] = float(value.strip()) 
if 'Improper Dih.' not in DATA.keys(): DATA['Improper Dih.'] = 1e-3 
DATA=OrderedDict(sorted(DATA.items()))
DATA['TORS'] = DATA['Improper Dih.'] + DATA['Fourier Dih.']
DATA['NB']   = DATA['Coulomb (SR)']+ DATA['Coulomb-14']+DATA['LJ (SR)']+ DATA['LJ-14']
print DATA['Bond'],DATA['Angle'],DATA['TORS'],DATA['NB'],DATA['Potential'] 
