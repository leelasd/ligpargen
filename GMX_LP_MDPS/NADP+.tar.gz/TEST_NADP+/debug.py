from simtk.openmm import app,KcalPerKJ
import simtk.openmm as mm
from simtk import unit as u
from sys import stdout,exit
import parmed as pmd
def OPLS_LJ(system):
        forces = { system.getForce(index).__class__.__name__ : system.getForce(index) for index in range(system.getNumForces()) }
        nonbonded_force = forces['NonbondedForce']
        lorentz=mm.CustomNonbondedForce('4*epsilon*((sigma/r)^12-(sigma/r)^6); sigma=sqrt(sigma1*sigma2); epsilon=sqrt(epsilon1*epsilon2)')
        lorentz.setNonbondedMethod(nonbonded_force.getNonbondedMethod())
        lorentz.addPerParticleParameter('sigma')
        lorentz.addPerParticleParameter('epsilon')
        lorentz.setCutoffDistance(nonbonded_force.getCutoffDistance())
        system.addForce(lorentz)
        LJset={}
        for index in range(nonbonded_force.getNumParticles()):
                charge,sigma,epsilon=nonbonded_force.getParticleParameters(index)
                LJset[index]=(sigma,epsilon)
                lorentz.addParticle([sigma,epsilon])
                nonbonded_force.setParticleParameters(index, charge, sigma, epsilon*0)
        for i in range(nonbonded_force.getNumExceptions()):
                (p1, p2, q, sig, eps) = nonbonded_force.getExceptionParameters(i)
                lorentz.addExclusion(p1,p2) ## ALL THE 12,13 and 14 interactions are EXCLUDED FROM CUSTOM NONBONDED FORCE
                if eps._value != 0.0:
                        sig14=u.sqrt(LJset[p1][0]*LJset[p2][0])
                        eps14=u.sqrt(LJset[p1][1]*LJset[p2][1])
                        nonbonded_force.setExceptionParameters(i, p1, p2, q, sig14, eps)
        return system



pdb = app.PDBFile('UNK.pdb')

modeller = app.Modeller(pdb.topology, pdb.positions)
forcefield = app.ForceField('UNK.xml')

system = forcefield.createSystem(modeller.topology, nonbondedMethod=app.NoCutoff,  constraints=None)
system = OPLS_LJ(system)
struct=pmd.load_file('UNK.pdb')
ecomps=(pmd.openmm.energy_decomposition_system(struct,system))
tot_ene=0.0
for i in range(0,len(ecomps)):
	tot_ene+=ecomps[i][1]
	print(ecomps[i][0],ecomps[i][1])
print('Total-energy %6.6f'%tot_ene)
