#!/bin/bash

#SBATCH --partition=gpu

#SBATCH --job-name=HIV

#SBATCH --ntasks=10 --nodes=1

#SBATCH --mem-per-cpu=6000 

#SBATCH --time=1:00:00

#SBATCH --mail-type=ALL

#SBATCH --mail-user=leela.dodda@yale.edu

#SBATCH --gres=gpu:1

module load  Apps/Plumed Apps/Gromacs/5.1.4-gpu
# FOR PLUMED-GMX MD JOB
mpirun gmx mdrun -s topol.tpr -plumed plumed_1.dat 
# FOR SIMPLE MD JOB
#mpirun gmx mdrun -s topol.tpr 
